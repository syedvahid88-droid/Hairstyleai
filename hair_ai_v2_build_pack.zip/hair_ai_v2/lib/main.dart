import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const HairAiApp());
}

class HairAiApp extends StatelessWidget {
  const HairAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Hair AI',
    theme: ThemeData(useMaterial3: true, brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff42d6a4), brightness: Brightness.dark)),
    home: const TryOnScreen());
}

class StyleInfo {
  final String name, category, description;
  final IconData icon;
  const StyleInfo(this.name, this.category, this.description, this.icon);
}
const styles = <StyleInfo>[
  StyleInfo('Classic','Classic','Natural, neat volume',Icons.content_cut),
  StyleInfo('Side Part','Classic','Swept cleanly to one side',Icons.waves),
  StyleInfo('Ivy League','Short','Short sides, tidy top',Icons.school),
  StyleInfo('Textured Crop','Short','Choppy texture and fringe',Icons.grain),
  StyleInfo('Crew Cut','Short','Low-maintenance short cut',Icons.person),
  StyleInfo('Buzz Cut','Short','Very short uniform length',Icons.circle),
  StyleInfo('Messy','Medium','Relaxed, tousled texture',Icons.auto_awesome),
  StyleInfo('Middle Part','Medium','Centre split with flow',Icons.vertical_align_center),
  StyleInfo('Curtains','Medium','Longer centre-parted fringe',Icons.air),
  StyleInfo('Quiff','Medium','Lifted front volume',Icons.trending_up),
  StyleInfo('Pompadour','Classic','Sculpted front volume',Icons.arrow_upward),
  StyleInfo('Taper','Classic','Natural gradual sides',Icons.linear_scale),
];

class TryOnScreen extends StatefulWidget {
  const TryOnScreen({super.key});
  @override State<TryOnScreen> createState()=>_TryOnScreenState();
}
class _TryOnScreenState extends State<TryOnScreen> {
  CameraController? camera;
  FaceDetector? detector;
  Face? face;
  bool busy=false, ready=false, mirror=true;
  String error='';
  int selected=0;
  double opacity=.82;
  String category='All';
  final categories=['All','Classic','Short','Medium'];

  @override void initState(){super.initState();_start();}
  Future<void> _start() async {
    try{
      final cs=await availableCameras();
      if(cs.isEmpty) throw Exception('No camera available');
      final c=cs.firstWhere((x)=>x.lensDirection==CameraLensDirection.front,orElse:()=>cs.first);
      camera=CameraController(c,ResolutionPreset.medium,enableAudio:false,imageFormatGroup:ImageFormatGroup.nv21);
      await camera!.initialize();
      detector=FaceDetector(options:FaceDetectorOptions(enableLandmarks:true,enableContours:false,enableClassification:false,performanceMode:FaceDetectorMode.fast));
      await camera!.startImageStream(_process);
      if(mounted)setState(()=>ready=true);
    }catch(e){if(mounted)setState(()=>error='Camera setup error: $e');}
  }
  Future<void> _process(CameraImage image)async{
    if(busy||detector==null||camera==null)return;
    busy=true;
    try{
      final bytes= image.planes.fold<List<int>>([], (a,p)=>a..addAll(p.bytes));
      final rot=InputImageRotationValue.fromRawValue(camera!.description.sensorOrientation)??InputImageRotation.rotation0deg;
      final fmt=InputImageFormatValue.fromRawValue(image.format.raw)??InputImageFormat.nv21;
      final input=InputImage.fromBytes(bytes:Uint8List.fromList(bytes),metadata:InputImageMetadata(size:Size(image.width.toDouble(),image.height.toDouble()),rotation:rot,format:fmt,bytesPerRow:image.planes.first.bytesPerRow));
      final found=await detector!.processImage(input);
      if(mounted)setState(()=>face=found.isEmpty?null:found.first);
    }catch(_){}
    busy=false;
  }
  Future<void> _capture()async{
    if(camera==null||!camera!.value.isInitialized)return;
    try{
      if(camera!.value.isStreamingImages)await camera!.stopImageStream();
      final file=await camera!.takePicture();
      if(mounted)await showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Photo saved'),content:Text('Captured image: ${file.path}\\nUse this photo to compare the selected haircut.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('OK'))]));
      await camera!.startImageStream(_process);
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Capture failed: $e')));}
  }
  @override void dispose(){camera?.dispose();detector?.close();super.dispose();}
  @override Widget build(BuildContext context){
    final filtered=styles.where((s)=>category=='All'||s.category==category).toList();
    return Scaffold(backgroundColor:const Color(0xff0b1015),body:SafeArea(child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(18,12,18,10),child:Row(children:[
        const Icon(Icons.auto_awesome,color:Color(0xff42d6a4)),const SizedBox(width:9),
        const Text('HAIR AI',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:2)),
        const Spacer(),IconButton(onPressed:()=>_about(),icon:const Icon(Icons.info_outline))
      ])),
      Expanded(flex:6,child:Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:ClipRRect(borderRadius:BorderRadius.circular(24),child:Stack(fit:StackFit.expand,children:[
        if(camera?.value.isInitialized==true)CameraPreview(camera!) else const Center(child:CircularProgressIndicator()),
        if(face!=null&&camera?.value.previewSize!=null)CustomPaint(painter:HairOverlayPainter(face!,camera!.value.previewSize!,selected,opacity,mirror)),
        Positioned(top:12,left:12,right:12,child:Container(padding:const EdgeInsets.symmetric(horizontal:13,vertical:9),decoration:BoxDecoration(color:Colors.black.withOpacity(.6),borderRadius:BorderRadius.circular(30)),child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(face==null?Icons.face_retouching_off:Icons.face_retouching_natural,color:const Color(0xff42d6a4),size:18),const SizedBox(width:8),Text(face==null?'Move into frame':'Face tracked • ${styles[selected].name}',style:const TextStyle(fontSize:12))]))),
        Positioned(bottom:12,right:12,child:IconButton.filled(onPressed:()=>setState(()=>mirror=!mirror),icon:Icon(mirror?Icons.flip:Icons.flip_camera_android),tooltip:'Mirror overlay')),
        if(error.isNotEmpty)Center(child:Padding(padding:const EdgeInsets.all(20),child:Text(error,textAlign:TextAlign.center)))
      ])))),
      Padding(padding:const EdgeInsets.fromLTRB(20,14,20,0),child:Row(children:[const Text('HAIR PREVIEW',style:TextStyle(fontWeight:FontWeight.bold,letterSpacing:1)),const Spacer(),Text('${styles.length} styles',style:const TextStyle(color:Colors.white54))])),
      Padding(padding:const EdgeInsets.fromLTRB(18,0,18,2),child:Row(children:[const Text('Overlay strength',style:TextStyle(fontSize:12,color:Colors.white70)),Expanded(child:Slider(value:opacity,min:.35,max:1,onChanged:(v)=>setState(()=>opacity=v)))])),
      SizedBox(height:36,child:ListView(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:14),children:categories.map((c)=>Padding(padding:const EdgeInsets.symmetric(horizontal:4),child:ChoiceChip(label:Text(c),selected:category==c,onSelected:(_)=>setState(()=>category=c)))).toList())),
      SizedBox(height:104,child:ListView.builder(scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:12),itemCount:filtered.length,itemBuilder:(ctx,i){
        final s=filtered[i];final idx=styles.indexOf(s);
        return GestureDetector(onTap:()=>setState(()=>selected=idx),child:Container(width:100,margin:const EdgeInsets.symmetric(horizontal:5,vertical:5),padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:selected==idx?const Color(0xff153e35):const Color(0xff202832),borderRadius:BorderRadius.circular(16),border:Border.all(color:selected==idx?const Color(0xff42d6a4):Colors.transparent)),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(s.icon,color:selected==idx?const Color(0xff42d6a4):Colors.white70,size:25),const SizedBox(height:5),Text(s.name,textAlign:TextAlign.center,style:const TextStyle(fontSize:11,fontWeight:FontWeight.w600)),Text(s.description,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:9,color:Colors.white54))])));
      })),
      Padding(padding:const EdgeInsets.fromLTRB(16,8,16,14),child:Row(children:[
        Expanded(child:FilledButton.icon(onPressed:face==null?null:_recommend,icon:const Icon(Icons.auto_awesome),label:const Text('Find my style'))),
        const SizedBox(width:10),IconButton.filledTonal(onPressed:face==null?null:_capture,icon:const Icon(Icons.camera_alt),tooltip:'Capture')
      ]))
    ])));
  }
  void _recommend(){
    setState(()=>selected=1);
    showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('Style suggestion'),content:const Text('Try a classic side part first. It is a versatile starting point, but this prototype does not yet estimate face shape. Compare a few styles in the preview and consider your hair texture and daily styling routine.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('OK'))]));
  }
  void _about()=>showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('About Hair AI'),content:const Text('This prototype uses ML Kit face detection to locate a face and draw a stylized overlay. The overlay is illustrative—not a realistic hair simulation. Hair segmentation and 3D tracking are future upgrades.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Close'))]));
}

class HairOverlayPainter extends CustomPainter{
  final Face face;final Size preview;final int style;final double alpha;final bool mirror;
  HairOverlayPainter(this.face,this.preview,this.style,this.alpha,this.mirror);
  @override void paint(Canvas canvas,Size size){
    final b=face.boundingBox;
    // Camera preview is rotated in portrait: map detector coordinates onto canvas.
    final sx=size.width/preview.height,sy=size.height/preview.width;
    final cx=(mirror?size.width-(b.left+b.width/2)*sx:(b.left+b.width/2)*sx);
    final cy=(b.top+b.height*.25)*sy;
    final w=b.width*sx*1.18,h=b.height*sy*.62;
    final r=Rect.fromCenter(center:Offset(cx,cy-h*.35),width:w,height:h);
    final path=Path();
    switch(style){
      case 1: // side-parted silhouette
        path.moveTo(r.left,r.bottom);path.quadraticBezierTo(r.left-r.width*.12,r.top+r.height*.25,r.center.dx-r.width*.1,r.top);path.quadraticBezierTo(r.right+r.width*.1,r.top-r.height*.05,r.right,r.bottom);path.quadraticBezierTo(r.center.dx,r.bottom+r.height*.1,r.left,r.bottom);break;
      case 7: case 8: // centre split
        path.moveTo(r.left,r.bottom);path.quadraticBezierTo(r.left-r.width*.08,r.top+r.height*.2,r.center.dx,r.top);path.quadraticBezierTo(r.right+r.width*.08,r.top+r.height*.2,r.right,r.bottom);path.lineTo(r.center.dx+r.width*.04,r.bottom*.98);path.quadraticBezierTo(r.center.dx,r.top+r.height*.32,r.center.dx-r.width*.04,r.bottom*.98);path.close();break;
      case 3: // fringe
        path.moveTo(r.left,r.bottom);path.quadraticBezierTo(r.left-r.width*.08,r.top,r.center.dx,r.top);path.quadraticBezierTo(r.right+r.width*.08,r.top,r.right,r.bottom);path.lineTo(r.center.dx+r.width*.1,r.bottom-r.height*.16);path.lineTo(r.center.dx,r.bottom-r.height*.05);path.lineTo(r.center.dx-r.width*.12,r.bottom-r.height*.13);path.close();break;
      case 5: // buzz
        path.addOval(Rect.fromCenter(center:r.center,width:r.width*.95,height:r.height*.62));break;
      default:
        path.moveTo(r.left,r.bottom);path.quadraticBezierTo(r.left-r.width*.1,r.top+r.height*.24,r.center.dx,r.top);path.quadraticBezierTo(r.right+r.width*.1,r.top+r.height*.24,r.right,r.bottom);path.quadraticBezierTo(r.center.dx,r.bottom+r.height*.08,r.left,r.bottom);break;
    }
    final fill=Paint()..color=const Color(0xff17120e).withOpacity(alpha)..style=PaintingStyle.fill;
    canvas.drawPath(path,fill);
    final sheen=Paint()..color=Colors.white.withOpacity(alpha*.11)..style=PaintingStyle.stroke..strokeWidth=2;
    canvas.drawPath(path,sheen);
    // small illustrative texture strokes
    final texture=Paint()..color=Colors.black.withOpacity(alpha*.18)..strokeWidth=2..strokeCap=StrokeCap.round;
    for(int i=0;i<5;i++){final x=r.left+r.width*(.18+i*.15);canvas.drawLine(Offset(x,r.top+r.height*.28),Offset(x+r.width*.06,r.top+r.height*.12),texture);}
  }
  @override bool shouldRepaint(covariant HairOverlayPainter o)=>o.face!=face||o.style!=style||o.alpha!=alpha||o.mirror!=mirror;
}
